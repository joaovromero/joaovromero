# Como instalar seu novo perfil

1. Extraia o ZIP no computador.
2. Abra o repositório público `joaovromero/joaovromero` no GitHub. Se ele ainda não existir, crie um repositório público chamado exatamente `joaovromero`.
3. Guarde uma cópia do README atual se quiser manter o modelo anterior.
4. No repositório, use **Add file → Upload files**. Arraste o arquivo **README.md** e a pasta **assets** deste pacote. Eles precisam ficar na raiz do repositório: não envie a pasta `perfil-github` como pasta intermediária e não envie o ZIP fechado.
5. Confira os arquivos e clique em **Commit changes**. Se usar uma branch, faça a integração à branch padrão para o perfil mostrar o resultado.
6. Abra https://github.com/joaovromero para conferir. Se alguma imagem não aparecer imediatamente, recarregue a página.

## Personalizar

Abra os arquivos `.svg` da pasta `assets` no VS Code. Eles são código editável: altere o texto entre as tags `<text>` e mantenha as coordenadas. Textos maiores podem precisar de redução em `font-size` ou quebra em outra tag `<text>`.

- `apresentacao.svg`: nome, idade, localização, monograma e título.
- `perfil.svg`: apresentação, graduação e interesse.
- `estudos.svg`: áreas de estudo.
- `linkedin.svg` e `repositorios.svg`: aparência dos botões; os links ficam no README.
- `rodape.svg`: agradecimento.

Atualize também os textos `alt` e a versão em texto do README quando mudar informações. A idade é estática: está em 18 anos, conforme o conteúdo fornecido.

Paleta: fundo dos cartões `#151F35`, fundo interno `#1C2B43`, azul `#2563EB`, verde `#00E5C3`, texto `#F4F7FF` e texto secundário `#CBD5E1`.

## Como funciona

Os blocos permanecem em posições estáveis no layout e usam sombras desenhadas para dar profundidade. Não ficam presos à tela durante a rolagem. O GitHub remove estilos inline e scripts do README; por isso o visual está nos SVGs, inseridos como imagens. Eles se ajustam à largura disponível, mas o texto também reduz em telas pequenas; a seção expansível traz uma versão de leitura em texto.

Não precisa instalar extensões, executar JavaScript, usar Live Server ou configurar Actions. Não há fontes remotas, APIs de estatísticas ou imagens externas no visual. Os links abrem seu LinkedIn e seus repositórios. O modelo preserva suas informações pessoais e de estudo; os painéis de métricas, troféus e cobra do modelo anterior foram retirados do novo design. Nenhuma quantidade ou proficiência foi inventada.

A prévia PNG é uma montagem local dos cartões. A interface externa e o espaçamento do GitHub podem variar. A publicação na sua conta deve ser feita por você.

Referências:
- https://docs.github.com/en/account-and-profile/how-tos/profile-customization/managing-your-profile-readme
- https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-readmes
- https://github.com/github/markup
